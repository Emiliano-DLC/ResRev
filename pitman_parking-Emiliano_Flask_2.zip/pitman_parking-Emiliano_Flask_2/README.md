# Software Construction Team 8 Project Repository
Created and edited by: Erick Garcia, Hiram Morales, Giovanna Munoz, Roman Soto, Emiliano de la Cruz, Valeria Martin del Campo, Alan Velasco

Workspace for the code that we will implement in later sprints
